from django.core.serializers import serialize
from django.shortcuts import render, get_object_or_404, redirect
from boards import models
import datetime
from django.http import Http404, JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from boards.forms import PostForm
import json


def post_list(request):
    post_order_like = models.Post.objects.all().order_by('-post_like')[:3]
    show_post_list = models.Post.objects.all().order_by('-id')
    if request.method == 'POST':
        new_post = models.Post()
        new_post.post_title = request.POST['post_title']
        if not new_post.post_title:
            return render(request, 'boards/post_write.html', {
                'err_msg1': '제목을 입력해주세요.',
                'hot_post': post_order_like,
                'post_list': show_post_list
            })
        new_post.post_writer = request.POST['post_writer']
        if not new_post.post_writer:
            return render(request, 'boards/post_write.html', {
                'hot_post': post_order_like,
                'post_list': show_post_list,
                'err_msg2': '작성자를 입력해주세요.'
            })
        new_post.post_content = request.POST['post_content']
        if not new_post.post_content:
            return render(request, 'boards/post_write.html', {
                'hot_post': post_order_like,
                'post_list': show_post_list,
                'err_msg3': '내용을 입력해주세요.'
            })

        new_post.pub_date = datetime.datetime.now()
        new_post.save()
        post_update_like = models.Post.objects.all().order_by('-post_like')[:3]
        post_update_show = models.Post.objects.all().order_by('-id')
        return render(request, 'boards/post_list.html', {
            'hot_post': post_update_like,
            'post_list': post_update_show
        })
    return render(request, 'boards/post_list.html', {
        'hot_post': post_order_like,
        'post_list': show_post_list
    })


@csrf_exempt
def post_content(request, post_id):
    content = get_object_or_404(models.Post, pk=post_id)
    if request.method == 'POST':
        if request.POST.get('what') == 'like':
            p = request.POST['id']
            current_post = get_object_or_404(models.Post, pk=p)
            current_post.post_like += 1
            current_post.save()
            return JsonResponse({'data': current_post.post_like})
        elif request.POST.get('what') == 'write_comment':
            new_comment = models.Comment()
            new_comment.comment_writer = request.POST['writer']
            new_comment.comment_text = request.POST['content']
            new_comment.post = get_object_or_404(models.Post, pk=request.POST['id'])
            new_comment.save()
            comment = models.Comment.objects.all().order_by('-id')
            writer_data = json.loads(serialize('json', comment))
            return JsonResponse({'comment': writer_data})
        elif request.POST.get('what') == 'comment_bring':
            comment = models.Comment.objects.all().order_by('-id')
            writer_data = json.loads(serialize('json', comment))
            return JsonResponse({'comment': writer_data})
        elif request.POST.get('what') == 'comment_delete':
            d_comment = get_object_or_404(models.Comment, pk=request.POST['id'])
            d_comment.delete()
            comment = models.Comment.objects.all().order_by('-id')
            writer_data = json.loads(serialize('json', comment))
            return JsonResponse({'comment': writer_data})
    a = 0
    b = 0
    if content == models.Post.objects.all().order_by('id')[0]:
        a = 1
        b_err_msg = '이전글이 없습니다.'
    else:
        x = 1
        while True:
            try:
                before_post = get_object_or_404(models.Post, pk=post_id - x)
            except Http404:
                x += 1
            else:
                break

    if content == models.Post.objects.all().order_by('-id')[0]:
        b = 1
        a_err_msg = '다음글이 없습니다.'
    else:
        x = 1
        while True:
            try:
                next_post = get_object_or_404(models.Post, pk=post_id + x)
            except Http404:
                x += 1
            else:
                break
    if a and b:
        return render(request, 'boards/post_content.html', {
            'post': content,
            'b_err_msg': b_err_msg,
            'a_err_msg': a_err_msg
        })
    if a:
        return render(request, 'boards/post_content.html', {
            'post': content,
            'b_err_msg': b_err_msg,
            'next_post': next_post
        })
    if b:
        return render(request, 'boards/post_content.html', {

            'post': content,
            'before_post': before_post,
            'a_err_msg': a_err_msg
        })
    return render(request, 'boards/post_content.html', {
        'post': content,
        'before_post': before_post,
        'next_post': next_post
    })


def post_write(request):
    post = models.Post.objects.all().order_by('-post.id')
    return render(request, 'boards/post_write.html', {
        'post': post
    })


def post_edit(request, post_id):
    post = models.Post.objects.get(pk=post_id)
    if request.method == 'POST':
        post.post_title = request.POST['post_title']
        post.post_content = request.POST['post_content']
        post.post_writer = request.POST['post_writer']
        post.pub_date = datetime.datetime.now()
        post.save()
        return redirect('/boards/')
    return render(request, 'boards/post_edit.html', {
        'post_edit': post
    })


def post_delete(request, post_pk):
    delete_post = models.Post.objects.get(pk=post_pk)
    delete_post.delete()
    return redirect('/boards/')


def p_ex(request):
    if request.POST == 'POST':
        post_form = PostForm()
        pass
    else:
        p_form = PostForm()
        return render(request, 'boards/hidden.html', {
            'p_form': p_form
        })
