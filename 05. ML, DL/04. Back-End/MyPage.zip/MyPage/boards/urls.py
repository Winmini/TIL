from django.urls import path
from . import views

app_name = 'boards'

urlpatterns = [
    path('', views.post_list, name='post_list'),
    path('<int:post_id>/', views.post_content, name="post_content"),
    path('<int:post_id>/edit/', views.post_edit, name="post_edit"),
    path('write/', views.post_write, name="post_write"),
    path('hidden/', views.p_ex, name="hidden")
]
