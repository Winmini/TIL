from django.db import models


class Post(models.Model):
    post_title = models.CharField(max_length=30)
    post_content = models.CharField(max_length=3000)
    post_writer = models.CharField(max_length=20)
    post_like = models.IntegerField(default=0)
    pub_date = models.DateTimeField()  # auto_now = true

    def __str__(self):
        return self.post_title


class Comment(models.Model):
    comment_text = models.CharField(max_length=50)
    comment_writer = models.CharField(max_length=20)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)

    def __str__(self):
        return self.comment_text
