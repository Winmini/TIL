$(function(event){
    $.ajax({
    type: 'POST',
    url: document.location.href,
    data: {
        'what': 'comment_bring',
        'id': $('#p_num').text(),
        'writer': $('#comment_writer').val(),
        'content': $('#comment_content').val()
    },
    success: function(data){
        $.each(data, function(idx,item){
            let c_list = $('#c_list');
            for(let i=0; i<$(item).length; i++){
                let c_info = $('<div>작성자: ' + $(item)[i].fields.comment_writer + '  내용: ' + $(item)[i].fields.comment_text + '</div>');
                let deleteBtn = $('<button type="button" class="btn btn-warning" style="text-align: right">  삭제</button>')
                c_list.append(c_info);
                c_info.append(deleteBtn);
                console.log($(item)[i].pk);
                deleteBtn.on('click', function (event){
                    $.ajax({
                        type: 'POST',
                        url: document.location.href,
                        data: {
                            'what': 'comment_delete',
                            'id': $(item)[i].pk,
                        },
                        success: function(data){
                            c_info.remove();
                        },
                        error: function(){
                            alert('댓글삭제 실패');
                        }
                    })
                })
            }
        })
    },
    error: function (){
        alert('댓글불러오기 실패');
    }
    })

    $('#comment_btn').on('click', function(event){
        $.ajax({
            type: 'POST',
            url: document.location.href,
            data: {
                'what': 'write_comment',
                'id': $('#p_num').text(),
                'writer': $('#comment_writer').val(),
                'content': $('#comment_content').val()
            },
            success: function(data){
                $.each(data, function(idx,item){
                    let c_list = $('#c_list');
                    c_list.empty();
                    console.log($(item).length)
                    console.log($(item)[0].fields.comment_text);
                    for(let i=0; i<$(item).length; i++){
                        let c_info = $('<div>작성자: ' + $(item)[i].fields.comment_writer + '  내용: ' + $(item)[i].fields.comment_text + '</div>');
                        let deleteBtn = $('<button type="button" class="btn btn-warning" style="text-align: right">  삭제</button>')
                        c_list.append(c_info);
                        c_info.append(deleteBtn);
                        deleteBtn.on('click', function (event){
                            $.ajax({
                                type: 'POST',
                                url: document.location.href,
                                data: {
                                    'what': 'comment_delete',
                                    'id': $(item)[i].pk,
                                },
                                success: function(data){
                                    c_info.remove();
                                },
                                error: function(){
                                    alert('댓글삭제 실패');
                                }
                            })
                        })
                    }
                })
            },
            error: function (){
                alert('댓글달기 실패');
            }
        })
    })
    $('#like_btn').on('click', function(event){
        let btn = $('#like_btn');
        $.ajax({
            type: 'POST',
            url: document.location.href,
            datatype: 'json',
            data: {
                'what': 'like',
                'id': btn.attr('value'),
            },
            success: function(data){
                console.log(data)
                $('#like_number').text(data['data']);
            },
            error: function(){
                alert('실패');
            }
        })
    })
})
