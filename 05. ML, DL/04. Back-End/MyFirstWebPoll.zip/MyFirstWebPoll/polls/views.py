from django.shortcuts import render, get_object_or_404
from polls import models
from django.http import HttpResponseRedirect
from django.urls import reverse


def index(request):
    q_list = models.Question.objects.all().order_by('-pub_date')
    context = {'question_list': q_list}
    return render(request, 'polls/index.html', context)


def detail(request, question_id):
    question = get_object_or_404(models.Question, pk=question_id)
    context = {'question': question}
    return render(request, 'polls/detail.html', context)


def vote(request, question_id):
    question = get_object_or_404(models.Question, pk=question_id)
    try:
        choice = question.choice_set.get(pk=request.POST['myChoice'])
    except(KeyError, models.Choice.DoesNotExist):
        return render(request, 'polls/detail.html', {
            'question': question,
            'err_msg': '아무것도 선택하지 않았습니다!'
        })
    else:
        choice.votes += 1
        choice.save() # 저장해야 올라감
        return HttpResponseRedirect(reverse('polls:results', args=(question_id,)))


def results(request, question_id):
    question = get_object_or_404(models.Question, pk=question_id)
    return render(request, 'polls/results.html', {
        'question':question
    })
